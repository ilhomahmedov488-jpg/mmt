import pdfplumber, json, re, pathlib, sys
root=pathlib.Path(__file__).resolve().parents[1]
rx=re.compile(r'^\s*(\d{6,})\s*[-–]\s*(.+)$', re.S)
cluster=int(sys.argv[1])
pdf=pathlib.Path(__file__).resolve().parents[2]/'official_lists'/f'plan_cluster_{cluster}_2026_ru.pdf'
items=[]; seen=set()
with pdfplumber.open(pdf) as doc:
    for page in doc.pages:
        for table in page.extract_tables():
            for row in table:
                if not row: continue
                cells=[re.sub(r'\s+',' ',(x or '')).strip() for x in row]
                desc_idx=next((i for i,x in enumerate(cells) if rx.match(x)),None)
                if desc_idx is None: continue
                m=rx.match(cells[desc_idx]); code,name=m.group(1),m.group(2).strip()
                # The printed PDF uses one fixed column layout for universities and another for colleges.
                if len(cells)>=17:
                    idv,org,city,mode,fee,lang,places=cells[0],cells[4],cells[6],cells[9],cells[10],cells[13],cells[14]
                    level='Колледж / среднее профессиональное'
                elif len(cells)>=11:
                    idv,org,city,mode,fee,lang,places=cells[0],cells[2],cells[4],cells[7],cells[8],cells[9],cells[10]
                    level='Вуз / высшее профессиональное'
                else: continue
                if not re.fullmatch(r'\d+',idv or ''): continue
                key=(idv,code,org,city,mode,fee,lang,places)
                if key in seen: continue
                seen.add(key)
                items.append({'id':idv,'cluster':cluster,'code':code,'specialty':name,'institution':org,'city':city,'level':level,'study_form':mode,'tuition':fee,'language':lang,'places':places})
out=root/'data'/f'cluster_{cluster}.json'
out.write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'cluster {cluster}: {len(items)} records -> {out}')
print('example:',json.dumps(items[:1],ensure_ascii=False))
