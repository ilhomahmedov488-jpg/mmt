window.MMT_BLUEPRINT = {
  1:{name:'Естественный и технический',minutes:220,subjects:['tajik','math','chemistry','physics']},
  2:{name:'Экономика и география',minutes:200,subjects:['tajik','math','geography','foreign']},
  3:{name:'Филология, педагогика и искусство',minutes:190,subjects:['tajik','history','literature','foreign']},
  4:{name:'Обществоведение и право',minutes:190,subjects:['tajik','history','law','foreign']},
  5:{name:'Медицина, биология и спорт',minutes:220,subjects:['tajik','biology','chemistry','physics']}
};
window.MMT_SUBJECTS={
  tajik:{ru:'Таджикский язык',tj:'Забони тоҷикӣ',icon:'А'},math:{ru:'Математика',tj:'Математика',icon:'∑'},chemistry:{ru:'Химия',tj:'Химия',icon:'⚗'},physics:{ru:'Физика',tj:'Физика',icon:'ϟ'},geography:{ru:'География',tj:'Ҷуғрофия',icon:'⌖'},foreign:{ru:'Иностранный язык',tj:'Забони хориҷӣ',icon:'文'},history:{ru:'История',tj:'Таърих',icon:'⌛'},literature:{ru:'Литература',tj:'Адабиёт',icon:'¶'},law:{ru:'Право',tj:'Ҳуқуқ',icon:'§'},biology:{ru:'Биология',tj:'Биология',icon:'⌬'}
};
