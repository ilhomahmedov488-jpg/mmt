#!/usr/bin/env bash
set -euo pipefail
GRADLE_VERSION=8.13
GRADLE_HOME="${HOME}/.gradle/mmt-gradle-${GRADLE_VERSION}"
if [[ ! -x "${GRADLE_HOME}/bin/gradle" ]]; then
  mkdir -p "${HOME}/.gradle"
  curl -fL "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" -o "/tmp/gradle-${GRADLE_VERSION}-bin.zip"
  unzip -oq "/tmp/gradle-${GRADLE_VERSION}-bin.zip" -d "${HOME}/.gradle"
  mv "${HOME}/.gradle/gradle-${GRADLE_VERSION}" "${GRADLE_HOME}"
  rm -f "/tmp/gradle-${GRADLE_VERSION}-bin.zip"
fi
if [[ -z "${ANDROID_HOME:-}" && -d "${HOME}/Android/Sdk" ]]; then export ANDROID_HOME="${HOME}/Android/Sdk"; fi
if [[ -z "${ANDROID_HOME:-}" ]]; then echo "Set ANDROID_HOME to an installed Android SDK (API 36 required)."; exit 1; fi
if [[ ! -f local.properties ]]; then printf 'sdk.dir=%s\n' "${ANDROID_HOME//\//\/}" > local.properties; fi
"${GRADLE_HOME}/bin/gradle" assembleDebug
printf '\nAPK created at app/build/outputs/apk/debug/app-debug.apk\n'
