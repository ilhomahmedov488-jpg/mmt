@echo off
setlocal
set "GRADLE_VERSION=8.13"
set "GRADLE_HOME=%USERPROFILE%\.gradle\mmt-gradle-%GRADLE_VERSION%"
set "GRADLE_ZIP=%TEMP%\gradle-%GRADLE_VERSION%-bin.zip"

if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Downloading Gradle %GRADLE_VERSION% from the official Gradle distribution site...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_ZIP%'; Expand-Archive -Force '%GRADLE_ZIP%' '%USERPROFILE%\.gradle\mmt-gradle-%GRADLE_VERSION%-unpack'; Move-Item -Force '%USERPROFILE%\.gradle\mmt-gradle-%GRADLE_VERSION%-unpack\gradle-%GRADLE_VERSION%' '%GRADLE_HOME%'; Remove-Item -Force '%GRADLE_ZIP%'; Remove-Item -Recurse -Force '%USERPROFILE%\.gradle\mmt-gradle-%GRADLE_VERSION%-unpack'"
  if errorlevel 1 (
    echo Gradle download failed. Check your internet connection and try again.
    exit /b 1
  )
)

if not exist "%LOCALAPPDATA%\Android\Sdk\platforms\android-36" (
  echo Android SDK 36 was not found. Install it in Android Studio: Tools ^> SDK Manager ^> SDK Platforms ^> Android 16 / API 36.
  exit /b 1
)

if not exist "local.properties" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "'sdk.dir=' + $env:LOCALAPPDATA.Replace('\','/') + '/Android/Sdk' | Set-Content -Encoding ASCII local.properties"
)

call "%GRADLE_HOME%\bin\gradle.bat" assembleDebug
if errorlevel 1 exit /b 1

echo.
echo APK created at: app\build\outputs\apk\debug\app-debug.apk
endlocal
